# FP-0002 v6 — SOURCE CHECK v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Method:** existence check only — no FIG inspection, no PDF inspection, no extraction

---

## Visual authority (JPG)

| File | Path | Exists |
|------|------|--------|
| HOME-PAGE-FULL-MOCKUP.jpg | `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/01_DESIGN/HOME-PAGE-FULL-MOCKUP.jpg` | YES |

---

## Branding assets

| Requested name | Exact path checked | Exists |
|----------------|-------------------|--------|
| logo.svg | `.../INCOMING/03_BRANDING/logo.svg` | YES |
| telegram.svg | `.../INCOMING/03_BRANDING/telegram.svg` | NO |
| whatsapp.svg | `.../INCOMING/03_BRANDING/whatsapp.svg` | NO |
| max.svg | `.../INCOMING/03_BRANDING/max.svg` | NO |

### Alternate filenames observed (existence only; not copied)

| File | Path | Exists |
|------|------|--------|
| Telegram-ico.svg | `.../INCOMING/03_BRANDING/Telegram-ico.svg` | YES |
| WhatsApp-ico.svg | `.../INCOMING/03_BRANDING/WhatsApp-ico.svg` | YES |
| MAX-ico.svg | `.../INCOMING/03_BRANDING/MAX-ico.svg` | YES |

---

## Forbidden sources (not inspected)

| Source | Inspected |
|--------|-----------|
| FIG | NO |
| PDF | NO |

---

## Notes

- Social icons at exact lowercase names (`telegram.svg`, `whatsapp.svg`, `max.svg`) were **not found** at the canonical branding path.
- Equivalent icons exist under different filenames (`Telegram-ico.svg`, `WhatsApp-ico.svg`, `MAX-ico.svg`). Renaming or copying is **out of scope** for this task.
- No content was extracted from any source file.

STOP.
