# FP-0002 v6 — SOURCE ACCESS GUARD v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Status:** ACTIVE

---

## Purpose

Define allowed and forbidden filesystem roots for FP-0002 v6 work. Any access outside allowed roots for design or implementation authority is a **contamination risk**.

---

## Allowed roots

| Root | Purpose |
|------|---------|
| `workspaces/fp-0002-shpigovsky-v6/` | Active v6 workspace (code, assets, reports, logs) |
| `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/01_DESIGN/HOME-PAGE-FULL-MOCKUP.jpg` | Primary and only design authority (single file) |
| `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/03_BRANDING/` | Logo and social icon sources |
| `shared/assets/icon-libraries/Font Awesome Pro 5.15.4/` | Shared icon library — only when explicitly needed |

**Note:** Listing or reading other files under `INCOMING/01_DESIGN/` (e.g. PDF, FIG) is **forbidden** even if the directory is partially allowed via the JPG path.

---

## Forbidden roots

| Root | Reason |
|------|--------|
| `workspaces/fp-0002-shpigovsky-frontend/` | v1 legacy |
| `workspaces/fp-0002-shpigovsky-v2/` | v2 legacy |
| `workspaces/fp-0002-shpigovsky-v3/` | v3 legacy |
| `workspaces/fp-0002-shpigovsky-v4/` | v4 legacy |
| `workspaces/fp-0002-shpigovsky-v5/` | v5 legacy |
| `Шпиговский.fig` (any path) | FIG forbidden |
| All PDF files in `INCOMING/01_DESIGN/` | PDF forbidden |
| `old reports/` (any legacy report trees outside v6 `reports/`) | Prior iteration authority |
| `old qa/` | Prior QA artifacts |
| `old logs/` | Prior iteration logs |

---

## On accidental forbidden access

1. **STOP** further work that depends on the contaminated read
2. **Record** in `logs/v6-violations.log`:
   - timestamp
   - violation description
   - file/source path
   - remediation taken
3. **Report contamination** to operator in task REPORT
4. Do **not** use forbidden content for decisions or implementation

---

## Logging requirement

Every allowed or forbidden source access must be appended to `logs/v6-source-access.log` with `status: allowed` or `status: forbidden`.

---

## Related documents

- `FP-0002-v6-JPG-ONLY-HARD-LAW-v1.md`
- `FP-0002-v6-EXECUTION-LOGGING-SYSTEM-v1.md`

STOP.
