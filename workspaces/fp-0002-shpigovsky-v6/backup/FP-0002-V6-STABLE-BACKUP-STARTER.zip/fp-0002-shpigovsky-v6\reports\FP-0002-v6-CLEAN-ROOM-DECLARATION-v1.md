# FP-0002 v6 — CLEAN ROOM DECLARATION v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Status:** ACTIVE — JPG-only visual authority

---

## Contamination exclusions

| Source | Used |
|--------|------|
| FIG | NOT USED |
| PDF | NOT USED |
| V1 (`fp-0002-shpigovsky-frontend/`) | NOT USED |
| V2 (`fp-0002-shpigovsky-v2/`) | NOT USED |
| V3 (`fp-0002-shpigovsky-v3/`) | NOT USED |
| V4 (`fp-0002-shpigovsky-v4/`) | NOT USED |
| V5 (`fp-0002-shpigovsky-v5/`) | NOT USED |

Old reports, old screenshots, old header builds, old footer builds, old geometry, old measurements, old DOM decisions, old audits, old discoveries, and old layout locks are **forbidden** for v6 work.

---

## VISUAL AUTHORITY

**HOME-PAGE-FULL-MOCKUP.jpg**

**ONLY**

Canonical path:

`C:\AI MARS\workspaces\website-factory-operations\FP-0002-SHPIGOVSKY\INCOMING\01_DESIGN\HOME-PAGE-FULL-MOCKUP.jpg`

No other file may override or supplement visual truth until an explicit human charter says otherwise.

---

## Scope of this declaration

This document establishes the clean-room boundary for FP-0002 v6. It does not authorize header, footer, hero, or any layout implementation.

STOP.
