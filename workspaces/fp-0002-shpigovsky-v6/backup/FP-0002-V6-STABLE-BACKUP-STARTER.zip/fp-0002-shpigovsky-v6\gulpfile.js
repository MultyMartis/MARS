const { src, dest, watch, series, parallel } = require('gulp');
const { deleteAsync } = require('del');
const fileInclude = require('gulp-file-include');
const plumber = require('gulp-plumber');
const sassCompiler = require('gulp-sass')(require('sass'));

const paths = {
  dist: 'dist',
  html: {
    pages: 'src/pages/**/*.html',
    watch: ['src/pages/**/*.html', 'src/partials/**/*.html'],
    dest: 'dist/',
  },
  styles: {
    src: 'src/scss/style.scss',
    watch: 'src/scss/**/*.scss',
    dest: 'dist/assets/css/',
  },
  scripts: {
    src: 'src/js/main.js',
    watch: 'src/js/**/*.js',
    dest: 'dist/assets/js/',
  },
  images: {
    src: 'src/img/**/*',
    watch: 'src/img/**/*',
    dest: 'dist/assets/img/',
  },
  svg: {
    src: 'src/svg/**/*',
    watch: 'src/svg/**/*',
    dest: 'dist/assets/svg/',
  },
  fonts: {
    src: 'src/fonts/**/*',
    watch: 'src/fonts/**/*',
    dest: 'dist/assets/fonts/',
  },
};

function onError(title) {
  return plumber({
    errorHandler(err) {
      console.error(`[${title}]`, err.message || err);
      this.emit('end');
    },
  });
}

async function cleanDist() {
  await deleteAsync([paths.dist]);
}

function html() {
  return src(paths.html.pages)
    .pipe(onError('HTML'))
    .pipe(
      fileInclude({
        prefix: '@@',
        basepath: __dirname + '/src',
      })
    )
    .pipe(dest(paths.html.dest));
}

function styles() {
  return src(paths.styles.src, { allowEmpty: true })
    .pipe(onError('SCSS'))
    .pipe(sassCompiler({ outputStyle: 'expanded' }).on('error', sassCompiler.logError))
    .pipe(dest(paths.styles.dest));
}

function scripts() {
  return src(paths.scripts.src, { allowEmpty: true })
    .pipe(onError('JS'))
    .pipe(dest(paths.scripts.dest));
}

function images() {
  return src(paths.images.src, { allowEmpty: true })
    .pipe(onError('Images'))
    .pipe(dest(paths.images.dest));
}

function svg() {
  return src(paths.svg.src, { allowEmpty: true })
    .pipe(onError('SVG'))
    .pipe(dest(paths.svg.dest));
}

function fonts() {
  return src(paths.fonts.src, { allowEmpty: true })
    .pipe(onError('Fonts'))
    .pipe(dest(paths.fonts.dest));
}

const build = series(cleanDist, parallel(html, styles, scripts, images, svg, fonts));

function watcher() {
  watch(paths.html.watch, html);
  watch(paths.styles.watch, styles);
  watch(paths.scripts.watch, scripts);
  watch(paths.images.watch, images);
  watch(paths.svg.watch, svg);
  watch(paths.fonts.watch, fonts);
}

exports.clean = cleanDist;
exports.build = build;
exports.default = build;
exports.watch = series(build, watcher);
