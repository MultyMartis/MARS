# FP-0002 v6 — JPG-ONLY HARD LAW v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Status:** ACTIVE — binding for all v6 build work

---

## PRIMARY AND ONLY DESIGN AUTHORITY

**HOME-PAGE-FULL-MOCKUP.jpg**

Canonical path:

`workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/01_DESIGN/HOME-PAGE-FULL-MOCKUP.jpg`

No other file may override, supplement, or replace visual and content truth for v6 active build unless an explicit human charter says otherwise.

---

## Forbidden for v6 active build

The following are **forbidden** as design, layout, measurement, or implementation authority:

- FIG (including `Шпиговский.fig` and any `.fig` file)
- PDF (all files in `INCOMING/01_DESIGN/` and elsewhere)
- Old reports
- Old screenshots
- Old measurements
- Old layout locks
- Old discoveries
- Old audits
- Old workspaces
- v1 / v2 / v3 / v4 / v5 code
- v1 / v2 / v3 / v4 / v5 SCSS
- v1 / v2 / v3 / v4 / v5 DOM decisions
- v1 / v2 / v3 / v4 / v5 assets — **except** if operator explicitly copies into v6

---

## Allowed sources

| Source | Path / note |
|--------|-------------|
| Primary mockup | `HOME-PAGE-FULL-MOCKUP.jpg` (see above) |
| Logo | `logo.svg` from `INCOMING/03_BRANDING/` |
| Social icons | `Telegram-ico.svg`, `WhatsApp-ico.svg`, `MAX-ico.svg` from `INCOMING/03_BRANDING/` (normalized copies in v6: `src/img/social/`) |
| Icon library | Font Awesome Pro 5.15.4 shared asset library (`shared/assets/icon-libraries/Font Awesome Pro 5.15.4/`) — **only if explicitly needed** |

**No other design files** are allowed for v6 active build.

---

## When information is not visible in JPG

1. Mark **SAFE UNKNOWN** in `logs/v6-safe-unknown.log`
2. **Ask operator** — do not guess from forbidden sources
3. **Do not inspect** FIG or PDF to fill gaps

---

## Enforcement

- All source access must be logged in `logs/v6-source-access.log`
- Accidental forbidden access → STOP, log in `logs/v6-violations.log`, report contamination
- See `FP-0002-v6-SOURCE-ACCESS-GUARD-v1.md` for allowed/forbidden roots

---

## Scope boundary

This law does **not** authorize header, footer, hero, or any layout implementation. It establishes source discipline only.

STOP.
