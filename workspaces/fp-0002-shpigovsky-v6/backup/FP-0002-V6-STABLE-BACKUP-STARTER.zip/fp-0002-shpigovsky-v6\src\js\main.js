// FP-0002 v6 — zero skeleton (no behavior)
