# FP-0002 v6 — SOCIAL ICON NORMALIZATION v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Phase:** A — Social icon normalization

---

## Purpose

Copy branding social icons from `03_BRANDING/` into v6 under normalized lowercase filenames. Source files in `03_BRANDING/` are **not** renamed.

---

## Source → destination mapping

| Source (03_BRANDING) | Destination (v6) | Action |
|----------------------|------------------|--------|
| `Telegram-ico.svg` | `src/img/social/telegram.svg` | COPIED |
| `WhatsApp-ico.svg` | `src/img/social/whatsapp.svg` | COPIED |
| `MAX-ico.svg` | `src/img/social/max.svg` | COPIED |

**Source paths (canonical):**

- `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/03_BRANDING/Telegram-ico.svg`
- `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/03_BRANDING/WhatsApp-ico.svg`
- `workspaces/website-factory-operations/FP-0002-SHPIGOVSKY/INCOMING/03_BRANDING/MAX-ico.svg`

**Destination paths:**

- `workspaces/fp-0002-shpigovsky-v6/src/img/social/telegram.svg`
- `workspaces/fp-0002-shpigovsky-v6/src/img/social/whatsapp.svg`
- `workspaces/fp-0002-shpigovsky-v6/src/img/social/max.svg`

---

## SVG content

SVG contents were **not modified**. Copy-only operation.

---

## Verification — source (`src/`)

| File | Exists |
|------|--------|
| `src/img/social/telegram.svg` | YES |
| `src/img/social/whatsapp.svg` | YES |
| `src/img/social/max.svg` | YES |

---

## Verification — build output (`dist/`)

Expected after `npm run build` (gulp `images` task copies `src/img/**/*` → `dist/assets/img/`):

| File | Expected path |
|------|---------------|
| `telegram.svg` | `dist/assets/img/social/telegram.svg` |
| `whatsapp.svg` | `dist/assets/img/social/whatsapp.svg` |
| `max.svg` | `dist/assets/img/social/max.svg |

Build verification recorded in `FP-0002-v6-JPG-ONLY-RULE-LOCK-AND-ASSET-SETUP-REPORT-v1.md`.

---

## Forbidden sources

| Source | Used |
|--------|------|
| FIG | NO |
| PDF | NO |
| Old workspaces (v1–v5) | NO |

---

## Status

**SOCIAL ICONS NORMALIZED — YES**

STOP.
