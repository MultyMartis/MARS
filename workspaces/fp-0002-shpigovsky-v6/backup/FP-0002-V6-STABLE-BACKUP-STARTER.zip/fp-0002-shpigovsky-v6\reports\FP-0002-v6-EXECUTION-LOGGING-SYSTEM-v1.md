# FP-0002 v6 — EXECUTION LOGGING SYSTEM v1

**Date:** 2026-06-22  
**Workspace:** `workspaces/fp-0002-shpigovsky-v6/`  
**Status:** ACTIVE

---

## Purpose

Provide append-only human-readable logs for every future v6 task. Agents and operators must **append** entries; do not overwrite or truncate prior history.

---

## Log files

| File | Purpose |
|------|---------|
| `logs/v6-decisions.log` | Architectural and source decisions |
| `logs/v6-actions.log` | File changes and build actions |
| `logs/v6-source-access.log` | Every source file/root accessed |
| `logs/v6-safe-unknown.log` | Information gaps requiring operator input |
| `logs/v6-violations.log` | Forbidden source access or rule breaches |

---

## Entry format (append-only)

### v6-decisions.log

```
---
timestamp: <ISO-8601>
decision: <what was decided>
source_used: <path or NONE>
reason: <why>
rejected_alternatives: <list or NONE>
---
```

### v6-actions.log

```
---
timestamp: <ISO-8601>
file_changed: <path>
action: <created|modified|copied|deleted|build|verify>
reason: <why>
expected_outcome: <what should result>
---
```

### v6-source-access.log

```
---
timestamp: <ISO-8601>
source_accessed: <path>
purpose: <why accessed>
status: <allowed|forbidden>
---
```

### v6-safe-unknown.log

```
---
timestamp: <ISO-8601>
unknown: <what is unknown>
why_unknown: <not visible in JPG / not in allowed sources / etc.>
needed_from_operator: <specific ask>
---
```

### v6-violations.log

```
---
timestamp: <ISO-8601>
violation: <description>
file_or_source: <path>
remediation: <what was done>
---
```

---

## Rules for future tasks

1. **Every** v6 task must append to relevant logs before closing.
2. Decisions that choose sources or reject alternatives → `v6-decisions.log`
3. Every file touch or build run → `v6-actions.log`
4. Every file read or directory listing of external sources → `v6-source-access.log`
5. Any gap in JPG-visible truth → `v6-safe-unknown.log` (do not fill from FIG/PDF)
6. Any forbidden access → `v6-violations.log` + STOP + contamination report

---

## Initialization

All five log files were created and seeded with entries for task **FP-0002 v6 JPG-ONLY RULE LOCK + SOCIAL ICON NORMALIZATION** (2026-06-22).

---

## Related documents

- `FP-0002-v6-JPG-ONLY-HARD-LAW-v1.md`
- `FP-0002-v6-SOURCE-ACCESS-GUARD-v1.md`
- `FP-0002-v6-CLEAN-ROOM-DECLARATION-v1.md`

STOP.
